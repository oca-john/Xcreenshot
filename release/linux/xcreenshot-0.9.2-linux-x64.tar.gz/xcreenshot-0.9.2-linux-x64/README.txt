Xcreenshot v0.9.2 - Portable Linux Version
=============================================

Cross-platform screenshot tool with annotation support.

Installation (User-level):
--------------------------
Run: ./install.sh

This will:
- Copy the binary to ~/bin/
- Create desktop entry in ~/.local/share/applications/
- Install icons to ~/.local/share/icons/

Uninstallation:
---------------
Run: ./uninstall.sh

Manual Run:
-----------
You can also run the application directly:
./xcreenshot

Requirements:
- libwebkit2gtk-4.1 (or webkit2gtk4.1 on Fedora)
- libappindicator3-1 (or libappindicator-gtk3 on Fedora)
